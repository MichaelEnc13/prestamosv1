
<?php include 'modulos/head.php' ?>

<?php include 'modulos/mods_index/jumbutron.php' ?>

<?php include 'modulos/mods_index/body.php' ?>

<?php include 'modulos/mods_index/ventajas.php' ?>

<?php include 'modulos/mods_index/oferta.php' ?>

<?php include 'modulos/footer.php' ?>
    
