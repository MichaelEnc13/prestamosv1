<?php 

//well solution
$dbserver = "mysql:host=localhost;dbname=u790594714_wellsolutions";
$dbuser= "u790594714_wellsolutions";
$dbpass = "Encarnacion132603@;

try {
    $conn =  new PDO($dbserver,$dbuser,$dbpass);
  //echo "conectado";
} catch (\Throwable $th) {
  // echo "error";
}
?>