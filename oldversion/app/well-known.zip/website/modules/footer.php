

<footer>

    
    <h2 style="text-align:center;"> WellSolutions</h2>
  <div class="info_container">
      
    <div class="info">
            <h2>Redes</h2>

            <a href="#" class="redes"><i class="fab fa-facebook-square"></i> Facebook</a>
            <a href="#" class="redes"><i class="fab fa-instagram"></i> Instagram</a>
            <a href="Contact#mail" class="redes"><i class="far fa-envelope-open"></i> Correo</a>

        </div>

        <div class="info">
            <h2>Más info</h2>
            <a href="Contact" >Contacto</a>
            <!-- <a href="#">Que es</a>
            <a href="#">Preguntas frecuentes</a> -->


        </div>
  </div>

    <small ><p style="text-align:center;">Founded in 2020</p></small>
</footer>



<script src="js/script.js"></script>
 <script src="icons/all.js"></script>   
</body>
</html>