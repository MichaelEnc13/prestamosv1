document.querySelector('.toggle').addEventListener('click',function(){
    document.querySelector('.nav_collapse').classList.toggle('collapsed')
});