<?php include 'modules/header.php' ?>

<div class="all_container">
<div class="advantage">
    <h2>Precio</h2>
   
</div>

<section class="main_content">

    <div class="pricing" id="price">
        <div class="cont_header">
             <i class="fas fa-walking"></i>
            <span> <i class="fas fa-dollar-sign"></i> 8.50/mensual</span>
            
         </div>

        <div class="cont_body">
             <span><i class="fas fa-check"></i> Los clientes que quieras</span>
            <span><i class="fas fa-check"></i> Respaldo de datos diario</span>
            <span><i class="fas fa-check"></i> Mantenimiento continuo</span>
            <span><i class="fas fa-check"></i> Soporte</span>
            <span><i class="fas fa-check"></i> Acceso desde cualquier dispositivo</span>
                 
        </div>

        <div class="cont_footer">
            <a href="Contact#mail">Contáctanos</a>
        </div>

    </div>

</section>
</div>

<?php include 'modules/footer.php' ?>