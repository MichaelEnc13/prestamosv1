<div class="confi-container">
    <h2 class="clt"><i class="fas fa-cog"></i>Configuraci&oacute;n</h2>
   <div class="configs cg-pass">
        <a href="change-pass" style="display:block;" class="cpass"><i class="fas fa-key"></i> Cambiar contrase&ntilde;a </a>
         <a href="pay" style="display:block;" class="cpass"><i class="fas fa-dollar-sign"></i> Formas de pago </a>

   </div>
</div>