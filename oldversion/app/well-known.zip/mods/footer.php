<!-- <script src="icons/all.js"></script> -->
<script src="js/scripts.js"></script>
<script src="mods/alert.js"></script>
</body>
</html>