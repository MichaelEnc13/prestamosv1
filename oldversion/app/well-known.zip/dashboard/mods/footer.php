<script src="js/script.js"></script>
<script src="icons/all.js"></script>
</body>
</html>